#include <iostream>

using namespace std;


void blastoffIter()
{
	for (int i = 10; i > 0; i--)
	{
		cout << "Countdown " << i << endl;
	}
	cout << "Blastoff@@@@@" << endl;
}

void blastoffRecur(int count)
{
	if (count > 0)
	{
		cout << "Recusion Countdown  " << count << endl;
		count--;
		blastoffRecur(count);
	}
	else
	{
		cout << "recusion blassoff" << endl;
		return;
	}
}
int main()
{
	int count;
	cout << "input a #" << endl;
	cin >> count;
	blastoffIter();
	blastoffRecur(count);
	return 0;
}